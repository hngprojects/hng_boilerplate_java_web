package hng_java_boilerplate.notificationSettings.service;

import hng_java_boilerplate.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class NotificationConsumerService {
@RabbitListener(queues = RabbitMQConfig.QUEUE_NAME)
    public void receiveNotification(String message){
        System.out.println("Received message:" + message);
    }
}
