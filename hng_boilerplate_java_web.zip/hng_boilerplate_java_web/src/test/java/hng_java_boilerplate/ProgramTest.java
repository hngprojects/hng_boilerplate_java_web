package hng_java_boilerplate;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProgramTest {

	@Test
	public void ItShouldPassForNoReason() {
		assertTrue(true);
	}

}
